<!-- app/Views/home.php -->
<?= $this->extend('layouts/master') ?>
<?= $this->section('content') ?>

<style>
.daterangepicker {
    z-index: 90000;

}

    </style>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <div class="page-title-right">
                               <ol class="breadcrumb m-0">
                                 <li class="breadcrumb-item"><a href="javascript: void(0);">Colaboradores</a></li>
                                 <li class="breadcrumb-item active">Adicionar</li>
                               </ol>
                            </div>
                            <h4 class="page-title">Novo Colaborador</h4>







                        </div>
                    </div>
                </div>
            </div> 
        </div>

   

<?= $this->endSection() ?>
