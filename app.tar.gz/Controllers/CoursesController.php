<?php

namespace App\Controllers;

class CoursesController extends BaseController
{
    public function index()
    {
        return view('CoursesView');
    }
}
